﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day24_Entity_Crud_app
{
    class Program
    {
        static void Main(string[] args)
        {
            ProjLocations db = new ProjLocations();
            
            int ch;

            do
            {
                Console.WriteLine("1 Insert record");
                Console.WriteLine("2 Display record");
                Console.WriteLine("3 Update record");
                Console.WriteLine("4 Delete record");
                Console.WriteLine("5 Search record");
                Console.WriteLine("6 Exit");
                ch = int.Parse(Console.ReadLine());
                City c = new City();
                int id;
                switch (ch)
                {
                    case 1: Console.WriteLine("Enter City id");
                            c.CityId = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter City Name");
                            c.Cityname = Console.ReadLine();
                            try
                            {
                                db.Cities.Add(c);
                                db.SaveChanges();
                            }
                            catch(Exception ob)
                            {
                                Console.WriteLine(ob.Message);
                            }
                            break;
                    case 2:foreach(City city in db.Cities)
                            {
                            Console.WriteLine("{0} :  {1}",city.CityId,city.Cityname);
                            }
                            break;
                    case 3:
                            Console.WriteLine("Enter City id");
                            id = int.Parse(Console.ReadLine());
                            c = db.Cities.Find(id);
                            if (c == null)
                                Console.WriteLine("The city id doesnt exist so cannot update ");
                            else
                            {
                                Console.WriteLine("Enter the City Name");
                                c.Cityname = Console.ReadLine();
                                db.SaveChanges();
                            }
                            break;

                    case 4:
                            Console.WriteLine("Enter City id");
                            id = int.Parse(Console.ReadLine());
                            c = db.Cities.Find(id);
                            if (c == null)
                                Console.WriteLine("The city id doesnt exist so cannot delete ");
                            else
                            {
                                db.Cities.Remove(c);
                                db.SaveChanges();
                            }
                            break;

                    case 5:
                            Console.WriteLine("Enter City id");
                            id = int.Parse(Console.ReadLine());
                            c = db.Cities.Find(id);
                            if(c==null)
                                Console.WriteLine("The city id doesnt exist");
                            else
                                Console.WriteLine("{0} :  {1}", c.CityId, c.Cityname);
                        break;
                    case 6:break;
                    default: Console.WriteLine("Invalid choice");break;
                }

            } while (ch != 6);

        }
    }
}
