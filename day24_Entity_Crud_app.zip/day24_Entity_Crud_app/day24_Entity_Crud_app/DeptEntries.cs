﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day24_Entity_Crud_app
{
    class DeptEntries
    {
        static void Main(string[] args)
        {
            ProjLocations db = new ProjLocations();
            DeptLoc dep = new DeptLoc();

            dep.AreaId = 8888;
            dep.AreaName = "Jayanagar road";
            dep.CityId = 222;
            try
            {
                db.DeptLocs.Add(dep);
                db.SaveChanges();
            }
            catch(Exception ob)
            {
                Console.WriteLine(ob.Message);
            }

            foreach(DeptLoc d in db.DeptLocs)
            {
                Console.WriteLine("{0} {1} {2} {3}",d.AreaId,d.AreaName,d.CityId,d.City.Cityname);
            }
        }
    }
}
